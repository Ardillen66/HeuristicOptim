#include "initialsolution.h"

using namespace std;

Initialsolution::Initialsolution() {}
Initialsolution::~Initialsolution() {}